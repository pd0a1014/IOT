#!/bin/bash

ps -ef | grep start_miflora.sh | grep -v grep | awk '{print "sudo kill -9 "$2}' | sh -v

echo "wait a scecond... Start sensing"


while true
do
      #echo "start command(miflora)"
      sudo /usr/bin/python3 /home/pi/Scanner/miflora_get.py --backend gatttool poll C4:7C:8D:64:25:0C &
      sudo /usr/bin/python3 /home/pi/Scanner/miflora_get.py --backend gatttool poll C4:7C:8D:66:39:30 &
      sudo /usr/bin/python3 /home/pi/Scanner/miflora_get.py --backend gatttool poll C4:7C:8D:66:36:88 &
      sleep 60
done

